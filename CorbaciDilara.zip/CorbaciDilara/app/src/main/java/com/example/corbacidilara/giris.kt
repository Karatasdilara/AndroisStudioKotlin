package com.example.corbacidilara

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.widget.TextView

class giris : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_giris)


        var yazi=findViewById<TextView>(R.id.isim)
        object : CountDownTimer(1000,60){
            var a=1
            override fun onTick(p0: Long) {
                yazi.setTextSize(a.toFloat())
                a = a + 3
            }

            override fun onFinish() {
                Handler().postDelayed(
                    {
                        var gecis = Intent(applicationContext, MainActivity::class.java)
                        startActivity(gecis)
                        finish()

                    },5000)
            }
        }.start()


    }
}

