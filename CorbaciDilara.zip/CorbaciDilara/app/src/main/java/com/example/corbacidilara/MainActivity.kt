package com.example.corbacidilara

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var b1 = findViewById<Button>(R.id.button1)
        var b2 = findViewById<Button>(R.id.button2)
        var b3 = findViewById<Button>(R.id.button3)
        var b4 = findViewById<Button>(R.id.button4)
        var b5 = findViewById<Button>(R.id.button5)
        var b6 = findViewById<Button>(R.id.button6)


        var t1 = findViewById<ImageView>(R.id.tik1)
        var t2 = findViewById<ImageView>(R.id.tik2)
        var t3 = findViewById<ImageView>(R.id.tik3)
        var t4 = findViewById<ImageView>(R.id.tik4)
        var t5 = findViewById<ImageView>(R.id.tik5)
        var t6 = findViewById<ImageView>(R.id.tik6)

        var bar = findViewById<ProgressBar>(R.id.progressBar)

        b1.setOnClickListener({
            if (t1.visibility == View.INVISIBLE) {
                t1.visibility = View.VISIBLE
            }
        })
        b2.setOnClickListener({
            if (t1.visibility == View.VISIBLE) {
                t2.visibility = View.VISIBLE
            }
        })
        b3.setOnClickListener({
            if (t1.visibility == View.VISIBLE && t2.visibility == View.VISIBLE) {
                t3.visibility = View.VISIBLE
            }
        })
        b4.setOnClickListener({
            if (t1.visibility == View.VISIBLE && t2.visibility == View.VISIBLE && t3.visibility == View.VISIBLE) {
                t4.visibility = View.VISIBLE
            }
        })
        b5.setOnClickListener({
            if (t1.visibility == View.VISIBLE && t2.visibility == View.VISIBLE && t3.visibility == View.VISIBLE && t4.visibility== View.VISIBLE) {
                t5.visibility = View.VISIBLE
            }
        })

        b6.setOnClickListener({
            if (t1.visibility == View.VISIBLE && t2.visibility == View.VISIBLE && t3.visibility == View.VISIBLE && t4.visibility == View.VISIBLE && t5.visibility == View.VISIBLE) {
                t6.visibility=View.VISIBLE
                bar.visibility = View.VISIBLE
                Handler().postDelayed({
                    var gecis = Intent(this, corba_secenekleri::class.java)
                    startActivity(gecis)
                    finish();
                }, 3000)
            }
        })




    }
}