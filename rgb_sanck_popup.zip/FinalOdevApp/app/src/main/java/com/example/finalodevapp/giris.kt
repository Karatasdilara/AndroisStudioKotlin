package com.example.finalodevapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat


val dosyayolu = "com.example.odevfinal"
val name = "isim"
val pin = "sifre"
var unutma = "unutma"


class giris : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_giris)

        var isim = findViewById<EditText>(R.id.PersonName)
        var sifre = findViewById<EditText>(R.id.Password)
        var remember = findViewById<Switch>(R.id.switch1)
        var progressBar = findViewById<ProgressBar>(R.id.progressBar2)

        var preferences = getSharedPreferences(dosyayolu, Context.MODE_PRIVATE)
        var editor = preferences.edit()

        Toast.makeText(applicationContext,
             "Kaydedilmiş İsim : ${preferences.getString(name,"Değer yok")} Şifre : ${preferences.getString(pin,"Değer yok")} Unutma : ${preferences.getString(unutma,"false")} ",Toast.LENGTH_SHORT).show()



        if(preferences.getString(name,"")=="Dilara Karatas"){
            isim.setText("Dilara Karatas")
        }
        if(preferences.getString(pin,"")=="02200201044"){
            sifre.setText("02200201044")
        }
        if(preferences.getString(name,"")=="Dilara Karatas" && preferences.getString(pin,"")=="02200201044"){
            Handler().postDelayed({
                var gecis = Intent(this@giris,Ekran::class.java)
                startActivity(gecis)
            },2000)
        }


        isim.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                var isimm = isim.text.toString()
                var sifree = sifre.text.toString()
                if(isimm=="Dilara Karatas" && sifree =="02200201044"){
                    if (remember.isChecked()== true) {
                        progressBar.visibility = View.VISIBLE
                        var unutmaa = "true"
                        editor.putString(unutma,unutmaa.toString())
                        editor.putString(name,isimm.toString())
                        editor.putString(pin,sifree.toString())
                        editor.apply()
                        var gecis = Intent(this@giris,Ekran::class.java )
                        startActivity(gecis)
                    } else{
                        progressBar.visibility = View.VISIBLE
                        var unutmaa = "false"
                        editor.putString(unutma,unutmaa.toString())
                        editor.remove(name)
                        editor.remove(pin)
                        editor.apply()
                        var gecis = Intent(this@giris,Ekran::class.java )
                        startActivity(gecis)

                    }
                }
            }
        })

        sifre.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                var isimm = isim.text.toString()
                var sifree = sifre.text.toString()
                if(isimm=="Dilara Karatas" && sifree =="02200201044"){
                    if (remember.isChecked()== true) {
                        progressBar.visibility = View.VISIBLE
                        var unutmaa = "true"
                        editor.putString(unutma,unutmaa.toString())
                        editor.putString(name,isimm.toString())
                        editor.putString(pin,sifree.toString())
                        editor.apply()
                        var gecis = Intent(this@giris,Ekran::class.java )
                        startActivity(gecis)
                    } else{
                        progressBar.visibility = View.VISIBLE
                        var unutmaa = "false"
                        editor.putString(unutma,unutmaa.toString())
                        editor.remove(name)
                        editor.remove(pin)
                        editor.apply()
                        var gecis = Intent(this@giris,Ekran::class.java )
                        startActivity(gecis)
                    }
                }
            }
        })

    }
}