package com.example.finalodevapp

import android.os.Bundle
import android.os.CountDownTimer
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

class FragmentAcilis : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        var fragacilis=inflater.inflate(R.layout.fragment_acilis,container,false)
        var ok = fragacilis.findViewById<ImageView>(R.id.ok)


        var durd = 1
        object : CountDownTimer(5000,500) {
            override fun onTick(p0: Long) {
                if(durd == 1){
                    ok.visibility = View.VISIBLE
                    durd = 2
                }else {
                    ok.visibility=View.INVISIBLE
                    durd = 1
                }

            }
            override fun onFinish() {
            }

        }.start()





        return fragacilis
    }

}
